# Live2D Proprietary Software License

*English*

[http://www.live2d.com/eula/live2d-proprietary-software-license-agreement_en.html]()


*Japanese*

[http://www.live2d.com/eula/live2d-proprietary-software-license-agreement_jp.html]()
