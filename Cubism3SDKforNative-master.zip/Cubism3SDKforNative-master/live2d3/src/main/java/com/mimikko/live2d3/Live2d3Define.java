package com.mimikko.live2d3;

/**
 * @author tory
 * @date 2019/6/3
 * @des:
 */
public class Live2d3Define {
    public static final int VERSION = 3;

    public static final String MODEL_FILE_EXT = ".model3.json";

    public static final String FILE_MODE_HITAREAS = "HitAreas";
    public static final String FILE_MODE_PHYSICS = "Physics";
}
